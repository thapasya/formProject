﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;


using System.IO;
using System.Reflection;
using System.Globalization;
using System.Runtime.InteropServices;
using System.Diagnostics;

namespace WebBrowser_HTML_File_CS
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        [StructLayout(LayoutKind.Sequential)]
        private struct KBDLLHOOKSTRUCT
        {
            public Keys key;
            public int scanCode;
            public int flags;
            public int time;
            public IntPtr extra;
        }
        //System level functions to be used for hook and unhook keyboard input  
        private delegate IntPtr LowLevelKeyboardProc(int nCode, IntPtr wParam, IntPtr lParam);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr SetWindowsHookEx(int id, LowLevelKeyboardProc callback, IntPtr hMod, uint dwThreadId);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern bool UnhookWindowsHookEx(IntPtr hook);
        [DllImport("user32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr CallNextHookEx(IntPtr hook, int nCode, IntPtr wp, IntPtr lp);
        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        private static extern IntPtr GetModuleHandle(string name);
        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        private static extern short GetAsyncKeyState(Keys key);
        //Declaring Global objects     
        private IntPtr ptrHook;
        private LowLevelKeyboardProc objKeyboardProcess;

        private IntPtr captureKey(int nCode, IntPtr wp, IntPtr lp)
        {
            if (nCode >= 0)
            {
                KBDLLHOOKSTRUCT objKeyInfo = (KBDLLHOOKSTRUCT)Marshal.PtrToStructure(lp, typeof(KBDLLHOOKSTRUCT));

                // Disabling 

                if (objKeyInfo.key == Keys.Tab && HasAltModifier(objKeyInfo.flags))
                {
                    return (IntPtr)1; // if 0 is returned then All the above keys will be enabled
                }
            }
            return CallNextHookEx(ptrHook, nCode, wp, lp);
        }

        bool HasAltModifier(int flags)
        {
            return (flags & 0x20) == 0x20;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            string curDir = Directory.GetCurrentDirectory();
            webBrowser1.Navigate(new Uri(String.Format("file:///C:/Users/Thapasya%20M/Desktop/WebBrowser_HTML_File_CS/HTML.htm")));
              this.TopMost = true;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;

         //   this.KeyPress += new KeyPressEventHandler(this.Form1_KeyPress);
          //  this.KeyDown += new KeyEventHandler(this.Form1_KeyDown);
                                  
            webBrowser1.DocumentCompleted +=
                new WebBrowserDocumentCompletedEventHandler(LoadedDocument);
            
            ProcessModule objCurrentModule = Process.GetCurrentProcess().MainModule;
            objKeyboardProcess = new LowLevelKeyboardProc(captureKey);
            ptrHook = SetWindowsHookEx(13, objKeyboardProcess, GetModuleHandle(objCurrentModule.ModuleName), 0);
        
    }
        private void LoadedDocument(object sender,
          WebBrowserDocumentCompletedEventArgs e)
        {            
            string culturesList = "";
            HtmlElement tableElem = webBrowser1.Document.GetElementById("language_list");

            CultureInfo[] cultures = CultureInfo.GetCultures(CultureTypes.InstalledWin32Cultures);
            foreach (CultureInfo culture in cultures)
            {
                if (culture.Name.Contains("-"))
                {
                    culturesList = culturesList + "<li>" + culture.EnglishName + "</li>";
                }
            }
            tableElem.InnerHtml = culturesList;            
        }
        // Keypress only handles keys in the ascii range
        private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("KeyPress: " + (int)e.KeyChar);
        }

        // Keydown will work for all keys
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            MessageBox.Show("KeyDown: " + e.KeyCode);
        }        
    }
}
